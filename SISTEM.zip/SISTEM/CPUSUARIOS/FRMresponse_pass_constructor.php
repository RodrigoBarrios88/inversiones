<?php

function Construye_Mail_Respuesta($fec,$nom,$usu,$pass,$mailadmin){
    $salida = '
          <!DOCTYPE html>
          <html>
          <head>
              <title></title>
              <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
              <style type="text/css">
          body {
            margin: 0;
            padding: 0;
            min-width: 100%;
          }
          table {
            border-collapse: collapse;
            border-spacing: 0;
          }
          td {
            padding: 0;
            vertical-align: top;
          }
          .spacer,
          .border {
            font-size: 1px;
            line-height: 1px;
          }
          .spacer {
            width: 100%;
          }
          img {
            border: 0;
            -ms-interpolation-mode: bicubic;
          }
          .image {
            font-size: 0;
            Margin-bottom: 24px;
          }
          .image img {
            display: block;
          }
          .logo img {
            display: block;
          }
          strong {
            font-weight: bold;
          }
          h1,
          h2,
          h3,
          p,
          ol,
          ul,
          li {
            Margin-top: 0;
          }
          ol,
          ul,
          li {
            padding-left: 0;
          }
          .btn a {
            mso-hide: all;
          }
          blockquote {
            Margin-top: 0;
            Margin-right: 0;
            Margin-bottom: 0;
            padding-right: 0;
          }
          .column-top {
            font-size: 32px;
            line-height: 32px;
          }
          .column-bottom {
            font-size: 8px;
            line-height: 8px;
          }
          .column {
            text-align: left;
          }
          .contents {
            width: 100%;
          }
          .padded {
            padding-left: 32px;
            padding-right: 32px;
          }
          .wrapper {
            display: table;
            table-layout: fixed;
            width: 100%;
            min-width: 620px;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
          }
          table.wrapper {
            table-layout: fixed;
          }
          .one-col,
          .two-col,
          .three-col {
            Margin-left: auto;
            Margin-right: auto;
            width: 600px;
          }
          .two-col .image {
            Margin-bottom: 23px;
          }
          .two-col .column-bottom {
            font-size: 9px;
            line-height: 9px;
          }
          .two-col .column {
            width: 300px;
          }
          .three-col .image {
            Margin-bottom: 21px;
          }
          .three-col .column-bottom {
            font-size: 11px;
            line-height: 11px;
          }
          .three-col .column {
            width: 200px;
          }
          .three-col .first .padded {
            padding-left: 32px;
            padding-right: 16px;
          }
          .three-col .second .padded {
            padding-left: 24px;
            padding-right: 24px;
          }
          .three-col .third .padded {
            padding-left: 16px;
            padding-right: 32px;
          }
          @media only screen {
            .wrapper {
              text-rendering: optimizeLegibility;
            }
          }
          @media only screen and (max-width: 620px) {
            [class*=wrapper] {
              min-width: 318px !important;
              width: 100% !important;
            }
            [class*=wrapper] .one-col,
            [class*=wrapper] .two-col,
            [class*=wrapper] .three-col {
              width: 318px !important;
            }
            [class*=wrapper] .column,
            [class*=wrapper] .gutter {
              display: block;
              float: left;
              width: 318px !important;
            }
            [class*=wrapper] .padded {
              padding-left: 32px !important;
              padding-right: 32px !important;
            }
            [class*=wrapper] .block {
              display: block !important;
            }
            [class*=wrapper] .hide {
              display: none !important;
            }
            [class*=wrapper] .image {
              margin-bottom: 24px !important;
            }
            [class*=wrapper] .image img {
              height: auto !important;
              width: 100% !important;
            }
          }
          .wrapper h1 {
            font-weight: 700;
          }
          .wrapper h2 {
            font-style: italic;
            font-weight: normal;
          }
          .wrapper h3 {
            font-weight: normal;
          }
          blockquote {
            font-style: italic;
          }
          .feature.one-col h1 {
            font-weight: normal;
          }
          .feature.one-col h2 {
            font-style: normal;
            font-weight: bold;
          }
          .feature.one-col h3 {
            font-style: italic;
          }
          td.border {
            width: 1px;
          }
          tr.border {
            background-color: #e9e9e9;
            height: 1px;
          }
          tr.border td {
            line-height: 1px;
          }
          .one-col,
          .two-col,
          .three-col {
            background-color: #ffffff;
            font-size: 14px;
          }
          .one-col,
          .two-col,
          .three-col,
          .preheader,
          .header,
          .footer {
            Margin-left: auto;
            Margin-right: auto;
          }
          .preheader table {
            width: 602px;
          }
          .preheader .title,
          .preheader .webversion {
            padding-top: 10px;
            padding-bottom: 12px;
            font-size: 12px;
            line-height: 21px;
          }
          .preheader .title {
            text-align: left;
          }
          .preheader .webversion {
            text-align: right;
            width: 300px;
          }
          .header {
            width: 602px;
          }
          .header .logo {
            font-size: 26px;
            font-weight: 700;
            letter-spacing: -0.02em;
            line-height: 32px;
            padding: 32px 0;
            text-align: center;
          }
          .header .logo a {
            text-decoration: none;
          }
          .header .logo img {
            Margin: 0 auto;
          }
          .wrapper a {
            text-decoration: underline;
            transition: all .2s;
          }
          .wrapper h1 {
            font-size: 36px;
            Margin-bottom: 18px;
          }
          .wrapper h2 {
            font-size: 26px;
            line-height: 32px;
            Margin-bottom: 20px;
          }
          .wrapper h3 {
            font-size: 18px;
            line-height: 22px;
            Margin-bottom: 16px;
          }
          .wrapper h1 a,
          .wrapper h2 a,
          .wrapper h3 a {
            text-decoration: none;
          }
          .wrapper .gray {
            background-color: #f7f7f7;
          }
          .wrapper .gray blockquote {
            border-left-color: #dddddd;
          }
          .wrapper .gray .divider table {
            background-color: #dddddd;
          }
          blockquote {
            font-size: 14px;
            border-left: 2px solid #e9e9e9;
            Margin-left: 0;
            padding-left: 16px;
          }
          table.divider {
            width: 100%;
          }
          .divider .inner {
            padding-bottom: 24px;
          }
          .divider table {
            background-color: #e9e9e9;
            font-size: 2px;
            line-height: 2px;
            width: 60px;
          }
          .image-frame {
            padding: 8px;
          }
          .image-background {
            display: inline-block;
          }
          .btn {
            Margin-bottom: 24px;
            padding: 2px;
          }
          .btn a {
            border: 1px solid #ffffff;
            display: inline-block;
            font-size: 13px;
            font-weight: bold;
            line-height: 15px;
            outline-style: solid;
            outline-width: 2px;
            padding: 10px 30px;
            text-align: center;
            text-decoration: none !important;
          }
          .one-col .column table:nth-last-child(2) td h1:last-child,
          .one-col .column table:nth-last-child(2) td h2:last-child,
          .one-col .column table:nth-last-child(2) td h3:last-child,
          .one-col .column table:nth-last-child(2) td p:last-child,
          .one-col .column table:nth-last-child(2) td ol:last-child,
          .one-col .column table:nth-last-child(2) td ul:last-child {
            Margin-bottom: 24px;
          }
          .one-col p,
          .one-col ol,
          .one-col ul {
            font-size: 16px;
            line-height: 24px;
          }
          .one-col ol,
          .one-col ul {
            Margin-left: 18px;
          }
          .two-col .column table:nth-last-child(2) td h1:last-child,
          .two-col .column table:nth-last-child(2) td h2:last-child,
          .two-col .column table:nth-last-child(2) td h3:last-child,
          .two-col .column table:nth-last-child(2) td p:last-child,
          .two-col .column table:nth-last-child(2) td ol:last-child,
          .two-col .column table:nth-last-child(2) td ul:last-child {
            Margin-bottom: 23px;
          }
          .two-col .image-frame {
            padding: 6px;
          }
          .two-col h1 {
            font-size: 26px;
            line-height: 32px;
            Margin-bottom: 16px;
          }
          .two-col h2 {
            font-size: 20px;
            line-height: 26px;
            Margin-bottom: 18px;
          }
          .two-col h3 {
            font-size: 16px;
            line-height: 20px;
            Margin-bottom: 14px;
          }
          .two-col p,
          .two-col ol,
          .two-col ul {
            font-size: 14px;
            line-height: 23px;
          }
          .two-col ol,
          .two-col ul {
            Margin-left: 16px;
          }
          .two-col li {
            padding-left: 5px;
          }
          .two-col .divider .inner {
            padding-bottom: 23px;
          }
          .two-col .btn {
            Margin-bottom: 23px;
          }
          .two-col blockquote {
            padding-left: 16px;
          }
          .three-col .column table:nth-last-child(2) td h1:last-child,
          .three-col .column table:nth-last-child(2) td h2:last-child,
          .three-col .column table:nth-last-child(2) td h3:last-child,
          .three-col .column table:nth-last-child(2) td p:last-child,
          .three-col .column table:nth-last-child(2) td ol:last-child,
          .three-col .column table:nth-last-child(2) td ul:last-child {
            Margin-bottom: 21px;
          }
          .three-col .image-frame {
            padding: 4px;
          }
          .three-col h1 {
            font-size: 20px;
            line-height: 26px;
            Margin-bottom: 12px;
          }
          .three-col h2 {
            font-size: 16px;
            line-height: 22px;
            Margin-bottom: 14px;
          }
          .three-col h3 {
            font-size: 14px;
            line-height: 18px;
            Margin-bottom: 10px;
          }
          .three-col p,
          .three-col ol,
          .three-col ul {
            font-size: 12px;
            line-height: 21px;
          }
          .three-col ol,
          .three-col ul {
            Margin-left: 14px;
          }
          .three-col li {
            padding-left: 6px;
          }
          .three-col .divider .inner {
            padding-bottom: 21px;
          }
          .three-col .btn {
            Margin-bottom: 21px;
          }
          .three-col .btn a {
            font-size: 12px;
            line-height: 14px;
            padding: 8px 19px;
          }
          .three-col blockquote {
            padding-left: 16px;
          }
          .feature .column-top {
            font-size: 36px;
            line-height: 36px;
          }
          .feature .column-bottom {
            font-size: 4px;
            line-height: 4px;
          }
          .feature .column {
            text-align: center;
          }
          .feature .image {
            Margin-bottom: 32px;
          }
          .feature.one-col .column table:nth-last-child(2) td h1:last-child,
          .feature.one-col .column table:nth-last-child(2) td h2:last-child,
          .feature.one-col .column table:nth-last-child(2) td h3:last-child,
          .feature.one-col .column table:nth-last-child(2) td p:last-child,
          .feature.one-col .column table:nth-last-child(2) td ol:last-child,
          .feature.one-col .column table:nth-last-child(2) td ul:last-child {
            Margin-bottom: 32px;
          }
          .feature.one-col h1,
          .feature.one-col h2,
          .feature.one-col h3 {
            text-align: center;
          }
          .feature.one-col h1 {
            font-size: 52px;
            line-height: 58px;
            Margin-bottom: 22px;
          }
          .feature.one-col h2 {
            font-size: 42px;
            Margin-bottom: 20px;
          }
          .feature.one-col h3 {
            font-size: 32px;
            line-height: 42px;
            Margin-bottom: 20px;
          }
          .feature.one-col p,
          .feature.one-col ol,
          .feature.one-col ul {
            font-size: 21px;
            line-height: 32px;
            Margin-bottom: 32px;
          }
          .feature.one-col p a,
          .feature.one-col ol a,
          .feature.one-col ul a {
            text-decoration: none;
          }
          .feature.one-col p {
            text-align: center;
          }
          .feature.one-col ol,
          .feature.one-col ul {
            Margin-left: 40px;
            text-align: left;
          }
          .feature.one-col li {
            padding-left: 3px;
          }
          .feature.one-col .btn {
            Margin-bottom: 32px;
            text-align: center;
          }
          .feature.one-col .divider .inner {
            padding-bottom: 32px;
          }
          .feature.one-col blockquote {
            border-bottom: 2px solid #e9e9e9;
            border-top: 2px solid #e9e9e9;
            border-left: none;
            Margin-bottom: 32px;
            padding-bottom: 42px;
            padding-left: 0;
            padding-top: 42px;
            position: relative;
          }
          .feature.one-col blockquote:before,
          .feature.one-col blockquote:after {
            background: -moz-linear-gradient(left, #ffffff 25%, #e9e9e9 25%, #e9e9e9 75%, #ffffff 75%);
            background: -webkit-gradient(linear, left top, right top, color-stop(25%, #ffffff), color-stop(25%, #e9e9e9), color-stop(75%, #e9e9e9), color-stop(75%, #ffffff));
            background: -webkit-linear-gradient(left, #ffffff 25%, #e9e9e9 25%, #e9e9e9 75%, #ffffff 75%);
            background: -o-linear-gradient(left, #ffffff 25%, #e9e9e9 25%, #e9e9e9 75%, #ffffff 75%);
            background: -ms-linear-gradient(left, #ffffff 25%, #e9e9e9 25%, #e9e9e9 75%, #ffffff 75%);
            background: linear-gradient(to right, #ffffff 25%, #e9e9e9 25%, #e9e9e9 75%, #ffffff 75%);
            display: block;
            height: 2px;
            left: 0;
            outline: 1px solid #ffffff;
            position: absolute;
            right: 0;
          }
          .feature.one-col blockquote:before {
            top: -2px;
          }
          .feature.one-col blockquote:after {
            bottom: -2px;
          }
          .feature.one-col blockquote p,
          .feature.one-col blockquote ol,
          .feature.one-col blockquote ul {
            font-size: 42px;
            line-height: 48px;
            Margin-bottom: 48px;
          }
          .feature.one-col blockquote p:last-child,
          .feature.one-col blockquote ol:last-child,
          .feature.one-col blockquote ul:last-child {
            Margin-bottom: 0 !important;
          }
          .footer {
            width: 602px;
          }
          .footer .padded {
            font-size: 12px;
            line-height: 20px;
          }
          .social {
            padding-top: 32px;
            padding-bottom: 22px;
          }
          .social img {
            display: block;
          }
          .social .divider {
            font-family: sans-serif;
            font-size: 10px;
            line-height: 21px;
            text-align: center;
            padding-left: 14px;
            padding-right: 14px;
          }
          .social .social-text {
            height: 21px;
            vertical-align: middle !important;
            font-size: 10px;
            font-weight: bold;
            text-decoration: none;
            text-transform: uppercase;
          }
          .social .social-text a {
            text-decoration: none;
          }
          .address {
            width: 250px;
          }
          .address .padded {
            text-align: left;
            padding-left: 0;
            padding-right: 10px;
          }
          .subscription {
            width: 350px;
          }
          .subscription .padded {
            text-align: right;
            padding-right: 0;
            padding-left: 10px;
          }
          .address,
          .subscription {
            padding-top: 32px;
            padding-bottom: 64px;
          }
          .address a,
          .subscription a {
            font-weight: bold;
            text-decoration: none;
          }
          .address table,
          .subscription table {
            width: 100%;
          }
          @media only screen and (max-width: 620px) {
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td h1:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td h1:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td h1:last-child,
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td h2:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td h2:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td h2:last-child,
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td h3:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td h3:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td h3:last-child,
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td p:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td p:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td p:last-child,
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td ol:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td ol:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td ol:last-child,
            [class*=wrapper] .one-col .column:last-child table:nth-last-child(2) td ul:last-child,
            [class*=wrapper] .two-col .column:last-child table:nth-last-child(2) td ul:last-child,
            [class*=wrapper] .three-col .column:last-child table:nth-last-child(2) td ul:last-child {
              Margin-bottom: 24px !important;
            }
            [class*=wrapper] .address,
            [class*=wrapper] .subscription {
              display: block;
              float: left;
              width: 318px !important;
              text-align: center !important;
            }
            [class*=wrapper] .address {
              padding-bottom: 0 !important;
            }
            [class*=wrapper] .subscription {
              padding-top: 0 !important;
            }
            [class*=wrapper] h1 {
              font-size: 36px !important;
              line-height: 42px !important;
              Margin-bottom: 18px !important;
            }
            [class*=wrapper] h2 {
              font-size: 26px !important;
              line-height: 32px !important;
              Margin-bottom: 20px !important;
            }
            [class*=wrapper] h3 {
              font-size: 18px !important;
              line-height: 22px !important;
              Margin-bottom: 16px !important;
            }
            [class*=wrapper] p,
            [class*=wrapper] ol,
            [class*=wrapper] ul {
              font-size: 16px !important;
              line-height: 24px !important;
              Margin-bottom: 24px !important;
            }
            [class*=wrapper] ol,
            [class*=wrapper] ul {
              Margin-left: 18px !important;
            }
            [class*=wrapper] li {
              padding-left: 2px !important;
            }
            [class*=wrapper] blockquote {
              padding-left: 16px !important;
            }
            [class*=wrapper] .two-col .column:nth-child(n + 3) {
              border-top: 1px solid #e9e9e9;
            }
            [class*=wrapper] .btn {
              margin-bottom: 24px !important;
            }
            [class*=wrapper] .btn a {
              display: block !important;
              font-size: 13px !important;
              font-weight: bold !important;
              line-height: 15px !important;
              padding: 10px 30px !important;
            }
            [class*=wrapper] .column-bottom {
              font-size: 8px !important;
              line-height: 8px !important;
            }
            [class*=wrapper] .first .column-bottom,
            [class*=wrapper] .three-col .second .column-bottom {
              display: none;
            }
            [class*=wrapper] .second .column-top,
            [class*=wrapper] .third .column-top {
              display: none;
            }
            [class*=wrapper] .image-frame {
              padding: 4px !important;
            }
            [class*=wrapper] .header .logo {
              font-size: 26px !important;
              line-height: 32px !important;
            }
            [class*=wrapper] .header .logo img {
              display: inline-block !important;
              max-width: 260px !important;
              height: auto !important;
            }
            [class*=wrapper] table.border,
            [class*=wrapper] .header,
            [class*=wrapper] .webversion,
            [class*=wrapper] .footer {
              width: 320px !important;
            }
            [class*=wrapper] .preheader .webversion,
            [class*=wrapper] .header .logo a {
              text-align: center !important;
            }
            [class*=wrapper] .preheader table,
            [class*=wrapper] .border td {
              width: 318px !important;
            }
            [class*=wrapper] .image .border td {
              width: auto !important;
            }
            [class*=wrapper] .title {
              display: none;
            }
            [class*=wrapper] .footer .padded {
              text-align: center !important;
            }
            [class*=wrapper] .footer .subscription .padded {
              padding-top: 20px !important;
            }
            [class*=wrapper] .footer .social-link {
              display: block !important;
            }
            [class*=wrapper] .footer .social-link table {
              margin: 0 auto 10px !important;
            }
            [class*=wrapper] .footer .divider {
              display: none !important;
            }
            [class*=wrapper] .feature .btn {
              margin-bottom: 28px !important;
            }
            [class*=wrapper] .feature .image {
              margin-bottom: 28px !important;
            }
            [class*=wrapper] .feature .divider .inner {
              padding-bottom: 28px !important;
            }
            [class*=wrapper] .feature h1 {
              font-size: 42px !important;
              line-height: 48px !important;
              margin-bottom: 20px !important;
            }
            [class*=wrapper] .feature h2 {
              font-size: 32px !important;
              line-height: 36px !important;
              margin-bottom: 18px !important;
            }
            [class*=wrapper] .feature h3 {
              font-size: 26px !important;
              line-height: 32px !important;
              margin-bottom: 20px !important;
            }
            [class*=wrapper] .feature p,
            [class*=wrapper] .feature ol,
            [class*=wrapper] .feature ul {
              font-size: 20px !important;
              line-height: 28px !important;
              margin-bottom: 28px !important;
            }
            [class*=wrapper] .feature blockquote {
              font-size: 18px !important;
              line-height: 26px !important;
              margin-bottom: 28px !important;
              padding-bottom: 26px !important;
              padding-left: 0 !important;
              padding-top: 26px !important;
            }
            [class*=wrapper] .feature blockquote p,
            [class*=wrapper] .feature blockquote ol,
            [class*=wrapper] .feature blockquote ul {
              font-size: 26px !important;
              line-height: 32px !important;
            }
            [class*=wrapper] .feature blockquote p:last-child,
            [class*=wrapper] .feature blockquote ol:last-child,
            [class*=wrapper] .feature blockquote ul:last-child {
              margin-bottom: 0 !important;
            }
            [class*=wrapper] .feature .column table:last-of-type h1:last-child,
            [class*=wrapper] .feature .column table:last-of-type h2:last-child,
            [class*=wrapper] .feature .column table:last-of-type h3:last-child {
              margin-bottom: 28px !important;
            }
          }
          @media only screen and (max-width: 320px) {
            [class*=wrapper] td.border {
              display: none;
            }
            [class*=wrapper] table.border,
            [class*=wrapper] .header,
            [class*=wrapper] .webversion,
            [class*=wrapper] .footer {
              width: 318px !important;
            }
          }
          </style>
              <!--[if mso]>
              <style>
                .spacer, .border, .border td, .column-top, .column-bottom {
                  mso-line-height-rule: exactly !important;
                }
              </style>
              <![endif]-->
            <meta name="robots" content="noindex,nofollow"></meta>
          <meta property="og:title" content="Mensaje a Inversiones Digitales S.A. Software"></meta>
          <link href="#" media="screen,projection" rel="stylesheet" type="text/css" />
          </head>
          <body style="margin: 0;padding: 0;min-width: 100%;background-color: #fbfbfb"><style type="text/css">
          body.noop{border-width:0px}body,.wrapper,.emb-editor-canvas{background-color:#fbfbfb}.border{background-color:#e9e9e9}h1{color:#565656}.wrapper h1{}.wrapper h1{font-family:Avenir,sans-serif}h1{}.one-col h1{line-height:42px}.two-col h1{line-height:32px}.three-col h1{line-height:26px}.feature h1{line-height:58px}@media only screen and (max-width: 620px){h1{line-height:42px !important}}h2{color:#555}.wrapper h2{}.wrapper h2{font-family:Georgia,serif}h2{}.one-col h2{line-height:32px}.two-col h2{line-height:26px}.three-col h2{line-height:22px}.feature h2{line-height:52px}@media only screen and (max-width: 620px){h2{line-height:32px !important}}h3{color:#555}.wrapper h3{}.wrapper h3{font-family:Georgia,serif}h3{}.one-col h3{line-height:26px}.two-col h3{line-height:22px}.three-col h3{line-height:20px}.feature h3{line-height:42px}@media only screen and (max-width: 620px){h3{line-height:26px 
          !important}}p,ol,ul{color:#565656}.wrapper p,.wrapper ol,.wrapper ul{}.wrapper p,.wrapper ol,.wrapper ul{font-family:Georgia,serif}p,ol,ul{}.one-col p,.one-col ol,.one-col ul{line-height:25px;Margin-bottom:25px}.feature p,.feature ol,.feature ul{line-height:32px}.feature blockquote p,.feature blockquote ol,.feature blockquote ul{line-height:50px}@media only screen and (max-width: 620px){p,ol,ul{line-height:25px !important;Margin-bottom:25px !important}}.wrapper a{color:#41637e}.wrapper a:hover{color:#30495c !important}.wrapper .logo{color:#41637e}.wrapper .logo{font-family:Avenir,sans-serif}.wrapper .logo a{color:#41637e}.wrapper .logo a:hover{color:#41637e !important}.wrapper .feature p a,.wrapper .feature ol a,.wrapper .feature ul a{border-bottom:1px solid #41637e}.wrapper .feature p a:hover,.wrapper .feature ol a:hover,.wrapper .feature ul a:hover{color:#30495c 
          !important;border-bottom:1px solid #30495c !important}.btn a{}.wrapper .btn a{}.wrapper .btn a{font-family:Georgia,serif}.wrapper .btn a{background-color:#41637e;color:#fff !important;outline-color:#41637e;text-shadow:0 1px 0 rgba(0,0,0,0.3)}.wrapper .btn a:hover{background-color:#3b5971 !important;color:#fff !important;outline-color:#3b5971 !important}.preheader .title,.preheader .webversion,.footer .padded{color:#999}.preheader .title,.preheader .webversion,.footer .padded{font-family:Georgia,serif}.preheader .title a,.preheader .webversion a,.footer .padded a{color:#999}.preheader .title a:hover,.preheader .webversion a:hover,.footer .padded a:hover{color:#737373 !important}.footer .social .divider{color:#e9e9e9}.footer .social .social-text,.footer .social a{color:#999}.wrapper .footer .social .social-text,.wrapper .footer .social a{}.wrapper .footer .social .social-text,.wrapper 
          .footer .social a{font-family:Georgia,serif}.footer .social .social-text,.footer .social a{}.footer .social .social-text,.footer .social a{letter-spacing:0.05em}.footer .social .social-text:hover,.footer .social a:hover{color:#737373 !important}.image .border{background-color:#c8c8c8}.image-frame{background-color:#dadada}.image-background{background-color:#f7f7f7}
          </style>
                <table class="wrapper" style="border-collapse: collapse;border-spacing: 0;display: table;table-layout: fixed;width: 100%;min-width: 620px;-webkit-text-size-adjust: 100%;-ms-text-size-adjust: 100%;text-rendering: optimizeLegibility;background-color: #fbfbfb">
                  <tbody><tr>
                    <td style="padding: 0;vertical-align: top">
                      <center>
                        <table class="preheader" style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto">
                          <tbody><tr>
                            <td style="padding: 0;vertical-align: top">
                              <table style="border-collapse: collapse;border-spacing: 0;width: 602px">
                                <tbody><tr>
                                  
                                  <td class="webversion" style="padding: 0;vertical-align: top;padding-top: 10px;padding-bottom: 12px;font-size: 12px;line-height: 21px;text-align: right;width: 300px;color: #999;font-family: Georgia,serif">
                                  </td>
                                </tr>
                              </tbody></table>
                            </td>
                          </tr>
                        </tbody></table>
                        <table class="header" style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto;width: 602px">
                          <tbody><tr><td class="border" style="padding: 0;vertical-align: top;font-size: 1px;line-height: 1px;background-color: #e9e9e9;width: 1px">&nbsp;</td></tr>
                          <tr><td class="logo" style="padding: 32px 0;vertical-align: top;font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;text-align: center;color: #41637e;font-family: Avenir,sans-serif" align="center"><center><div id="emb-email-header">
                          <img style="border: 0;-ms-interpolation-mode: bicubic;display: block;Margin: 0 auto;max-width: 450px" src="'.$_SERVER['SERVER_NAME'].'HELPME/images/baner.png" alt="" width="300" height="55"></div></center></td></tr>
                        </tbody></table>
                        
                            <table class="border" style="border-collapse: collapse;border-spacing: 0;font-size: 1px;line-height: 1px;background-color: #e9e9e9;Margin-left: auto;Margin-right: auto" width="602">
                              <tbody><tr><td style="padding: 0;vertical-align: top">&#8203;</td></tr>
                            </tbody></table>
                          
                            <table style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto">
                              <tbody><tr>
                                <td class="border" style="padding: 0;vertical-align: top;font-size: 1px;line-height: 1px;background-color: #e9e9e9;width: 1px">&#8203;</td>
                                <td style="padding: 0;vertical-align: top">
                                  <table class="one-col" style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto;width: 600px;background-color: #ffffff;font-size: 14px">
                                    <tbody><tr>
                                      <td class="column" style="padding: 0;vertical-align: top;text-align: left">
                                        <div><div class="column-top" style="font-size: 32px;line-height: 32px">&nbsp;</div></div>
                                          <table class="contents" style="border-collapse: collapse;border-spacing: 0;width: 100%">
                                            <tbody><tr>
                                              <td class="padded" style="padding: 0;vertical-align: top;padding-left: 32px;padding-right: 32px">
                                                
                                                  <h1 style="Margin-top: 0;color: #565656;font-weight: 700;font-size: 36px;Margin-bottom: 18px;font-family: Avenir,sans-serif;line-height: 42px">Usuario y Contrase&ntilde;a del Sistema</h1>
                                                  <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Guatemala '.$fec.'</p>
                                                  <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px; text-align: justify;"><br>
                                                  ESTIMADO USUARIO: '.$nom.',<br>
                                                  ESTE ES UN CORREO DE RESPUESTA A SU PETICI&Oacute;N PARA RECIBIR SU USUARIO Y COTRASE&Ntilde;A DE NUESTRO SISTEMA, <br>
                                                  SU USUARIO ES: '.$usu.', <br> CONTRASE&Ntilde;A: '.$pass.'  <br> SI TIENE ALGUNA DUDA O PREGUNTA PARA EL ADMINISTRADOR DEL SISTEMA, PUEDE ENVIAR UN CORREO A '.$mailadmin.', EXPLICANDO SU PROBLEMA.";<p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px; text-align: justify;">
                                                  </p>
                                                  <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px; text-align: justify;">
                                                  Correo para Comunicarse:'.$mail.'
                                                  </p>
                                                  <blockquote style="Margin-top: 0;Margin-right: 0;Margin-bottom: 0;padding-right: 0;font-style: italic;font-size: 10px;border-left: 2px solid #e9e9e9;Margin-left: 0;padding-left: 16px">
                                                  <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 14px;line-height: 25px;Margin-bottom: 24px">
                                                  <a style="text-decoration: underline;transition: all .2s;color: #41637e" href="#">
                                                    Anular la suscripci&#243;n
                                                  </a>
                                                  <br>
                                                    Centro de perfiles<br>
                                                  <br>
                                                  </p>
                                                  <p style="Margin-top: 0;color: #565656;font-family: Georgia,serif;font-size: 12px;line-height: 25px;Margin-bottom: 24px; text-align: center;">
                                                  <br>
                                                  Este correo electr&#243;nico fue enviado por: Inversiones Digitales S.A. Software<br>
                                                  Guatemala, Centro America</p></blockquote>
                            
                                              </td>
                                            </tr>
                                          </tbody></table>
                                        
                                        <div class="column-bottom" style="font-size: 8px;line-height: 8px">&nbsp;</div>
                                      </td>
                                    </tr>
                                  </tbody></table>
                                </td>
                                <td class="border" style="padding: 0;vertical-align: top;font-size: 1px;line-height: 1px;background-color: #e9e9e9;width: 1px">&#8203;</td>
                              </tr>
                            </tbody></table>
                          
                            <table class="border" style="border-collapse: collapse;border-spacing: 0;font-size: 1px;line-height: 1px;background-color: #e9e9e9;Margin-left: auto;Margin-right: auto" width="602">
                              <tbody><tr><td style="padding: 0;vertical-align: top">&#8203;</td></tr>
                            </tbody></table>
                          
                        <div class="spacer" style="font-size: 1px;line-height: 32px;width: 100%">&nbsp;</div>
                        <table class="footer" style="border-collapse: collapse;border-spacing: 0;Margin-left: auto;Margin-right: auto;width: 602px">
                          <tbody><tr>
                            <td class="social" style="padding: 0;vertical-align: top;padding-top: 32px;padding-bottom: 22px" align="center">
                              <table style="border-collapse: collapse;border-spacing: 0">
                                <tbody><tr>
                                  <td class="social-link" style="padding: 0;vertical-align: top">
                                    <table style="border-collapse: collapse;border-spacing: 0">
                                      <tbody><tr>
                                        <td style="padding: 0;vertical-align: top">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="#" rel="cs_facebox">
                                            <img style="border: 0;-ms-interpolation-mode: bicubic;display: block" src="http://i6.createsend1.com/static/eb/master/01-mason/images/facebook-dark.png" width="26" height="21">
                                          </a>
                                        </td>
                                        <td class="social-text" style="padding: 0;vertical-align: middle !important;height: 21px;font-size: 10px;font-weight: bold;text-decoration: none;text-transform: uppercase;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="#" rel="cs_facebox">
                                            Like
                                          </a>
                                        </td>
                                      </tr>
                                    </tbody></table>
                                  </td>
                                  <td class="divider" style="padding: 0;vertical-align: top;font-family: sans-serif;font-size: 10px;line-height: 21px;text-align: center;padding-left: 14px;padding-right: 14px;color: #e9e9e9">
                                    <img style="border: 0;-ms-interpolation-mode: bicubic;display: block" src="http://i8.createsend1.com/static/eb/master/01-mason/images/diamond.png" width="5" height="21" alt="">
                                  </td>
                                  <td class="social-link" style="padding: 0;vertical-align: top">
                                    <table style="border-collapse: collapse;border-spacing: 0">
                                      <tbody><tr>
                                        <td style="padding: 0;vertical-align: top">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="#">
                                            <img style="border: 0;-ms-interpolation-mode: bicubic;display: block" src="http://i5.createsend1.com/static/eb/master/01-mason/images/twitter-dark.png" width="26" height="21">
                                          </a>
                                        </td>
                                        <td class="social-text" style="padding: 0;vertical-align: middle !important;height: 21px;font-size: 10px;font-weight: bold;text-decoration: none;text-transform: uppercase;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="#">
                                            Tweet
                                          </a>
                                        </td>
                                      </tr>
                                    </tbody></table>
                                  </td>
                                  <td class="divider" style="padding: 0;vertical-align: top;font-family: sans-serif;font-size: 10px;line-height: 21px;text-align: center;padding-left: 14px;padding-right: 14px;color: #e9e9e9">
                                    <img style="border: 0;-ms-interpolation-mode: bicubic;display: block" src="http://i8.createsend1.com/static/eb/master/01-mason/images/diamond.png" width="5" height="21" alt="">
                                  </td>
                                  <td class="social-link" style="padding: 0;vertical-align: top">
                                    <table style="border-collapse: collapse;border-spacing: 0">
                                      <tbody><tr>
                                        <td style="padding: 0;vertical-align: top">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="http://client.forwardtomyfriend.com/t-l-2AD73FFF-jhzpl-l-k">
                                            <img style="border: 0;-ms-interpolation-mode: bicubic;display: block" src="http://i7.createsend1.com/static/eb/master/01-mason/images/forward-dark.png" width="26" height="21">
                                          </a>
                                        </td>
                                        <td class="social-text" style="padding: 0;vertical-align: middle !important;height: 21px;font-size: 10px;font-weight: bold;text-decoration: none;text-transform: uppercase;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif">
                                          <a style="text-decoration: none;transition: all .2s;color: #999;letter-spacing: 0.05em;font-family: Georgia,serif" href="http://client.forwardtomyfriend.com/t-l-2AD73FFF-jhzpl-l-u">
                                            Forward
                                          </a>
                                        </td>
                                      </tr>
                                    </tbody></table>
                                  </td>
                                </tr>
                              </tbody></table>
                            </td>
                          </tr>
                          <tr><td class="border" style="padding: 0;vertical-align: top;font-size: 1px;line-height: 1px;background-color: #e9e9e9;width: 1px">&nbsp;</td></tr>
                          <tr>
                            <td style="padding: 0;vertical-align: top">
                              <table style="border-collapse: collapse;border-spacing: 0">
                                <tbody><tr>
                                  <td class="address" style="padding: 0;vertical-align: top;width: 250px;padding-top: 32px;padding-bottom: 64px">
                                    <table class="contents" style="border-collapse: collapse;border-spacing: 0;width: 100%">
                                      <tbody><tr>
                                        <td class="padded" style="padding: 0;vertical-align: top;padding-left: 0;padding-right: 10px;text-align: left;font-size: 12px;line-height: 20px;color: #999;font-family: Georgia,serif">
                                          
                                        </td>
                                      </tr>
                                    </tbody></table>
                                  </td>
                                  <td class="subscription" style="padding: 0;vertical-align: top;width: 350px;padding-top: 32px;padding-bottom: 64px">
                                    <table class="contents" style="border-collapse: collapse;border-spacing: 0;width: 100%">
                                      <tbody><tr>
                                        <td class="padded" style="padding: 0;vertical-align: top;padding-left: 10px;padding-right: 0;font-size: 12px;line-height: 20px;color: #999;font-family: Georgia,serif;text-align: right">
                                          
                                          <div>
                                            <span class="block">
                                              <span>
                                                <a style="font-weight: bold;text-decoration: none;transition: all .2s;color: #999" href="#">
                                                  Preferencias
                                                </a>
                                                <span class="hide">&nbsp;&nbsp;|&nbsp;&nbsp;</span>
                                              </span>
                                            </span>
                                            <span class="block"><a style="font-weight: bold;text-decoration: none;transition: all .2s;color: #999" href="#">Anular la suscripci&oacute;n </a></span>
                                          </div>
                                        </td>
                                      </tr>
                                    </tbody></table>
                                  </td>
                                </tr>
                              </tbody></table>
                            </td>
                          </tr>
                        </tbody></table>
                      </center>
                    </td>
                  </tr>
                </tbody></table>
            <img style="border: 0 !important;-ms-interpolation-mode: bicubic;height: 1px !important;width: 1px !important;margin: 0 !important;padding: 0 !important" src="http://createsend1.com/t/t-o-jhzpl-l/o.gif" width="1px" height="1px" border="0" alt="">
          <script type="text/javascript" src="http://js.createsend1.com/js/jquery-1.7.2.min.js?h=C99A4659canvas2"></script>
          <div id="fb-root"></div>
          <script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
          
          <script type="text/javascript" src="http://js.createsend1.com/js/track.min.js?h=B7B39702canvas2"></script>
          <script type="text/javascript">
          $(document).ready(function () {
              CS.WebVersion.setup({"LikeActionBase":"/t/t-fb-jhzpl-l-","IsSubscriber":false});
          });
          </script>
          </body>
          </html>
    ';
    return $salida;
}

//echo Construye_Mail_Respuesta("15/11/2014","MANUEL SOSA","farasi","prueba","manuelsa@farasi.com.gt");
?>