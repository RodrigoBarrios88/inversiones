<?php 
require_once("../../SISTEM/Clases/ClsInformacion.php");
require_once("../../SISTEM/Clases/ClsPushup.php");
require_once("../constructor.php"); //--correos
require_once("../recursos/mandrill/src/Mandrill.php"); //--correos
include_once('../push/push_android.php');



?>