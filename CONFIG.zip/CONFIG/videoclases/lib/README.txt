Kaltura PHP 5 API Client Library.
Compatible with Kaltura server version 16.5.0 and above.
